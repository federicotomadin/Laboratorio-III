namespace clases{


export enum Tipos{
    perro,
    gato,
    reptil,
    roedor,
    ave,
    pez
}
}


