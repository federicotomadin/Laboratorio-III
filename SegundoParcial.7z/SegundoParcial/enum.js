"use strict";
var clases;
(function (clases) {
    var Tipos;
    (function (Tipos) {
        Tipos[Tipos["perro"] = 0] = "perro";
        Tipos[Tipos["gato"] = 1] = "gato";
        Tipos[Tipos["reptil"] = 2] = "reptil";
        Tipos[Tipos["roedor"] = 3] = "roedor";
        Tipos[Tipos["ave"] = 4] = "ave";
        Tipos[Tipos["pez"] = 5] = "pez";
    })(Tipos = clases.Tipos || (clases.Tipos = {}));
})(clases || (clases = {}));
